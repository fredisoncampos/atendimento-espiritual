#!/usr/bin/env bash
# Gera os pacotes Linux do Atendimento Espiritual:
#   - .deb (Ubuntu, Mint, Pop!_OS, Debian)
#   - versão portátil .tar.gz (demais distros) com INSTALAR.sh
#
# Uso:  bash instalador/build-linux.sh <versao> <caminho-do-node-linux>
#   ex: bash instalador/build-linux.sh 1.9.4 /opt/node22/bin/node
#
# Requer: dpkg-deb, tar. O "node" passado precisa ser o binário Node.js 22 (Linux x64).
set -euo pipefail

VERSAO="${1:?informe a versao, ex: 1.9.4}"
NODE_BIN="${2:?informe o caminho do node Linux, ex: /opt/node22/bin/node}"

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
APP="$RAIZ/app"
ICONE="$RAIZ/instalador/icone.png"
SAIDA="$RAIZ/dist"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$SAIDA"

[ -x "$NODE_BIN" ] || { echo "node Linux nao encontrado/executavel: $NODE_BIN"; exit 1; }

# ---------- conteúdo comum (app + node) ----------
prep_payload() { # $1 = destino que conterá app/ e node
  local dst="$1"
  mkdir -p "$dst/app/public" "$dst/node"
  cp "$APP/server.js" "$dst/app/server.js"
  cp "$APP/public/"*.* "$dst/app/public/"
  cp "$NODE_BIN" "$dst/node/node"
  chmod +x "$dst/node/node"
}

# =========================================================
# 1) Pacote .deb  ->  /opt/atendimento-espiritual
# =========================================================
DEB="$TMP/deb"
mkdir -p "$DEB/DEBIAN" "$DEB/opt/atendimento-espiritual" \
         "$DEB/usr/bin" "$DEB/usr/share/applications" \
         "$DEB/usr/share/icons/hicolor/256x256/apps"
prep_payload "$DEB/opt/atendimento-espiritual"

cat > "$DEB/opt/atendimento-espiritual/iniciar.sh" <<'SH'
#!/usr/bin/env bash
# Inicia o Sistema de Atendimento Espiritual e abre no navegador.
set -e
AQUI="/opt/atendimento-espiritual"
export ATENDIMENTO_DADOS="$HOME/.local/share/AtendimentoEspiritual"
mkdir -p "$ATENDIMENTO_DADOS"
PORTA="${PORTA:-3210}"
URL="http://localhost:$PORTA"
# se ja estiver rodando, so abre o navegador
if ! curl -s -o /dev/null "$URL" 2>/dev/null; then
  "$AQUI/node/node" --no-warnings "$AQUI/app/server.js" >/dev/null 2>&1 &
  for i in $(seq 1 30); do curl -s -o /dev/null "$URL" 2>/dev/null && break; sleep 0.3; done
fi
( command -v xdg-open >/dev/null && xdg-open "$URL" ) >/dev/null 2>&1 || true
SH
chmod +x "$DEB/opt/atendimento-espiritual/iniciar.sh"

ln -s /opt/atendimento-espiritual/iniciar.sh "$DEB/usr/bin/atendimento-espiritual"
cp "$ICONE" "$DEB/usr/share/icons/hicolor/256x256/apps/atendimento-espiritual.png"

cat > "$DEB/usr/share/applications/atendimento-espiritual.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Atendimento Espiritual
Comment=Sistema de atendimento fraterno para casas espíritas
Exec=/opt/atendimento-espiritual/iniciar.sh
Icon=atendimento-espiritual
Terminal=false
Categories=Office;
DESK

TAM=$(du -ks "$DEB/opt" | cut -f1)
cat > "$DEB/DEBIAN/control" <<CTRL
Package: atendimento-espiritual
Version: $VERSAO
Section: utils
Priority: optional
Architecture: amd64
Depends: curl
Installed-Size: $TAM
Maintainer: Fredison Campos e colaboradores
Description: Sistema de Atendimento Espiritual
 Software livre e gratuito para casas espiritas organizarem o
 atendimento fraterno. Funciona na rede local, sem internet.
 Os dados ficam em ~/.local/share/AtendimentoEspiritual.
CTRL

dpkg-deb --build --root-owner-group "$DEB" \
  "$SAIDA/atendimento-espiritual_${VERSAO}_amd64.deb" >/dev/null
echo "OK  dist/atendimento-espiritual_${VERSAO}_amd64.deb"

# =========================================================
# 2) Versão portátil .tar.gz  (INSTALAR.sh cria o atalho)
# =========================================================
PORT="$TMP/atendimento-espiritual-linux-portatil-$VERSAO"
mkdir -p "$PORT"
prep_payload "$PORT"
cp "$ICONE" "$PORT/icone.png"

cat > "$PORT/iniciar.sh" <<'SH'
#!/usr/bin/env bash
# Inicia o sistema a partir da propria pasta (versao portatil).
set -e
AQUI="$(cd "$(dirname "$0")" && pwd)"
export ATENDIMENTO_DADOS="$HOME/.local/share/AtendimentoEspiritual"
mkdir -p "$ATENDIMENTO_DADOS"
PORTA="${PORTA:-3210}"
URL="http://localhost:$PORTA"
if ! curl -s -o /dev/null "$URL" 2>/dev/null; then
  "$AQUI/node/node" --no-warnings "$AQUI/app/server.js" >/dev/null 2>&1 &
  for i in $(seq 1 30); do curl -s -o /dev/null "$URL" 2>/dev/null && break; sleep 0.3; done
fi
( command -v xdg-open >/dev/null && xdg-open "$URL" ) >/dev/null 2>&1 || true
SH
chmod +x "$PORT/iniciar.sh"

cat > "$PORT/INSTALAR.sh" <<'SH'
#!/usr/bin/env bash
# Cria um atalho "Atendimento Espiritual" no menu de aplicativos, apontando
# para esta pasta. Nao precisa de administrador. Para remover, apague esta
# pasta e o arquivo ~/.local/share/applications/atendimento-espiritual.desktop
set -e
AQUI="$(cd "$(dirname "$0")" && pwd)"
APPS="$HOME/.local/share/applications"
ICONS="$HOME/.local/share/icons"
mkdir -p "$APPS" "$ICONS"
cp "$AQUI/icone.png" "$ICONS/atendimento-espiritual.png"
cat > "$APPS/atendimento-espiritual.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Atendimento Espiritual
Comment=Sistema de atendimento fraterno para casas espíritas
Exec=$AQUI/iniciar.sh
Icon=$ICONS/atendimento-espiritual.png
Terminal=false
Categories=Office;
DESK
chmod +x "$APPS/atendimento-espiritual.desktop"
echo
echo "Pronto! Procure por 'Atendimento Espiritual' no menu de aplicativos."
echo "Se preferir, clique duas vezes em iniciar.sh nesta pasta."
echo
SH
chmod +x "$PORT/INSTALAR.sh"

cat > "$PORT/LEIA-ME.txt" <<TXT
Sistema de Atendimento Espiritual $VERSAO - versao portatil (Linux)

COMO USAR
  1. Clique duas vezes em INSTALAR.sh (ou rode: bash INSTALAR.sh).
     Isso cria o atalho "Atendimento Espiritual" no menu de aplicativos.
  2. Abra pelo menu, ou clique em iniciar.sh nesta pasta.
  3. O sistema abre no navegador. Entre com Admin / 123456 e troque a senha.

ONDE FICAM OS DADOS
  Em  ~/.local/share/AtendimentoEspiritual  (nao ficam dentro desta pasta).
  Os backups ficam na subpasta "backups" desse local.

OUTROS APARELHOS NA REDE
  Em Configuracoes > Acesso por outros aparelhos aparece o endereco
  (ex.: http://192.168.0.10:3210) para tablets e celulares no mesmo Wi-Fi.

Requer uma distro Linux 64 bits. O Node.js ja vem incluso (pasta node).
Licenca AGPL-3.0. Codigo: https://github.com/fredisoncampos/atendimento-espiritual
TXT

tar -C "$TMP" -czf \
  "$SAIDA/atendimento-espiritual-linux-portatil-$VERSAO.tar.gz" \
  "atendimento-espiritual-linux-portatil-$VERSAO"
echo "OK  dist/atendimento-espiritual-linux-portatil-$VERSAO.tar.gz"
